% Sum the integers from 1 to N without recursion using the formula N * (N + 1) / 2
sum_to_n(N, Sum) :-
    Sum is N * (N + 1) // 2.

